import React from 'react';
import PollHeader from '../components/PollHeader.js';
import PollQuestion from '../components/PollQuestion.js';
import PollSubmitButton from '../components/PollSubmitButton.js';
import RadioButtonGroup from '../components/RadioButtonGroup.js';
import CurrentChoice from '../components/CurrentChoice';

class PollContainer extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            header: 'Welcome to the poll!',
            question: 'How much more do you want to learn today?',
            correctAnswer: 'Tacos',
            checkedValue: ''
        };
        this.setCheckedValue = this.setCheckedValue.bind(this);
    }
    
    setCheckedValue(value){
        this.setState({
            checkedValue: value
        });
        //console.log('current choice: ' + value);
    }

    render() {
        const choices = [
            {value: 'Tacos', label: 'I\'m totally down to keep going until lab 23'},
            {value: 'Pizza', label: 'Let\'s stick to the schedule and stop after 21'},
            {value: 'Cheese', label: 'I\'ve learn so much that I\'m going to explode'},
            {value: 'Wine', label: 'Happy Hour Starts at 3:30!'},
        ];

        const rowStyle = {
            backgroundColor: '#dadada',
            border: '1px solid black',
            borderRadius: '6px',
            padding: '10px'
        };
        
        return (
            <div className="container">
                <div className="jumbotron">
                    <PollHeader text={this.state.header} />
                </div>
                <div className="row" style={rowStyle}>
                    <div className="col-sm-4 col-sm-offset-4">
                    <form>
                        <PollQuestion text={this.state.question} />
                            <RadioButtonGroup
                                name = 'answer'
                                checkedValue = {this.state.checkedValue}
                                choices = {choices} 
                                changeHandler = {this.setCheckedValue}
                            />
                        <CurrentChoice checked = {this.state.checkedValue} />

                        <PollSubmitButton />
                    </form>
                    </div>
                </div>
            </div>
        );
    }
}

export default PollContainer;