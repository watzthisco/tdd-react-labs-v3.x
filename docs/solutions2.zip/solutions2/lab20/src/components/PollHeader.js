import React from 'react';

export default props => <h1 className="text-center">{props.text}</h1>
