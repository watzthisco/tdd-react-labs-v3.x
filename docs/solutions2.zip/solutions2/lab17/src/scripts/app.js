import React from 'react';
import ReactDOM from 'react-dom';
import PollContainer from '../containers/PollContainer';

ReactDOM.render(
    <PollContainer />,
    document.getElementById('app')
);