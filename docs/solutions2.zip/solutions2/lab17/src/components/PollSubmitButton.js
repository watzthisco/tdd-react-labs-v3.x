import React from 'react';

class PollSubmitButton extends React.Component{
    render(){
        return (<button>Go!</button>);
    }
}
export default PollSubmitButton;