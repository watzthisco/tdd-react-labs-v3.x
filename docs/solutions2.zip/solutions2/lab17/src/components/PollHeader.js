import React from 'react';

class PollHeader extends React.Component{
    render(){
        return (<h1>Welcome</h1>);
    }
}
export default PollHeader;