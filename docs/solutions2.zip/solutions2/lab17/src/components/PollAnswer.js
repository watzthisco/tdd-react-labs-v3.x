import React from 'react';

class PollAnswer extends React.Component{
    render(){
        return (
            <div>
                <label><input type="radio" /> Answer 1</label>
            </div>
        );
    }
}
export default PollAnswer;