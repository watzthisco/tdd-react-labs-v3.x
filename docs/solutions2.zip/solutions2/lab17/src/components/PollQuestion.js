import React from 'react';

class PollQuestion extends React.Component{
    render(){
        return (<h2>What is the question?</h2>);
    }
}
export default PollQuestion;