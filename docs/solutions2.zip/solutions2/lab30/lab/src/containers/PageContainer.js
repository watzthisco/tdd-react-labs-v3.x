import React from 'react';
import HelloWorld from '../components/HelloWorld';

class PageContainer extends React.Component {
    render() {
        return(
            <HelloWorld text = "Everybody"/>
        )
    }
}

export default PageContainer;