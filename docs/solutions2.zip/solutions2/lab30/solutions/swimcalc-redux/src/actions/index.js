export const changeCost = (value) => {
    return {
        type: 'CHANGE_COST',
        value
    }
};

export const changeNumber = (value) => {
    return {
        type: 'CHANGE_NUMBER',
        value
    }
};

export const changeInitial = (value) => {
    return {
        type: 'CHANGE_INITIAL',
        value
    }
};

export const changeIncrement = (value) => {
    return {
        type: 'CHANGE_INCREMENT',
        value
    }
};