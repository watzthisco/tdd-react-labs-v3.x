# My Project
This is my project

## Installation
1. Install Node.js 
2. Install git.
3. In the console, type: npm install


## Usage
To build:

1. npm run build


## Credits

## License
