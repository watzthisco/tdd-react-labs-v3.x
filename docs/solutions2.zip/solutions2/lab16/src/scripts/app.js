import React from 'react';
import ReactDOM from 'react-dom';

import SayHello from './SayHello';



ReactDOM.render(
    <SayHello name="World" />,
        document.getElementById('app')
);