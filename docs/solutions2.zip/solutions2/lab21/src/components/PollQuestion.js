import React from 'react';

function PollQuestion(props){
    return (<h2>{props.text}</h2>);
}
export default PollQuestion;