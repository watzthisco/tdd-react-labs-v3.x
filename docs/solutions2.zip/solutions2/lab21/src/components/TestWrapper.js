import React from 'react';

class TestWrapper extends React.Component{
    render(){
        return this.props.children;
    }
}

export default TestWrapper;