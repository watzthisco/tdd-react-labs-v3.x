import React from 'react';

function PollSubmitButton(){
    return (
        <button className="btn btn-success">Go!</button>
    );
}
export default PollSubmitButton;