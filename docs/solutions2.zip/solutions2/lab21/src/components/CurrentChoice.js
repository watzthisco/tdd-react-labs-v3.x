import React from 'react';

function CurrentChoice(props){
    return(<div>Current selection: {props.checked}</div>);
}

export default CurrentChoice;