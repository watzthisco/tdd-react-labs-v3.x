# React Project Template

React Project Template with automated build.

## Installation

1. Install Node
2. In the console, type: npm install

## Usage

To build:

1. npm run build

To run:

1. npm start

## Notes

* webpack-dev-server doesn't watch files correctly if the files are in 
  dropbox, or if your editor uses 'safe saving'. Disable this in 
  webstorm.

## Credits

## License
