import React from 'react';
import PropTypes from "prop-types";

function PollHeader(props) {
    return (<h1 className="text-center">{props.text}</h1>);
}

PollHeader.propTypes = {
    text: PropTypes.string

};

PollHeader.defaultProps = {
    text: "Hi"
};
export default PollHeader;